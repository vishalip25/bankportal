// database configurations handled here

module.exports = {
    HOST: "0.0.0.0",
    PORT: 3000,
    DB_URL: "mongodb+srv://vijayvijay1997:sunder.vj@cluster0.s3gkt.mongodb.net/Bank-Retail",
    ADMIN_COLLECTION: "Admin"
  };